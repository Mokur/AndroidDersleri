package com.example.lab08.sql.Adapter.Helper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.example.lab08.sql.Model.Rehber;

import java.util.ArrayList;
import java.util.List;


public class DatabaseHelper extends SQLiteOpenHelper {
    private static final int VERITABANI_SURUMU = 1;
    private static final String VERITABANI_ADI = "RehberDatabase";
    private static final String DB_TABLO_REHBER = "Rehber";
    private static final String TABLO_REHBERID = "id";
    private static final String TABLO_REHBER_AD = "ad";
    private static final String TABLO_REHBER_SOYAD = "soyad";
    private static final String TABLO_REHBER_TELEFONNO = "telefonNo";
    private static final String TABLO_REHBER_MAILADRESI = "mailAdresi";
    private static final String TABLO_REHBER_TELEFONTURU = "telefonTuru";
    private static final String TABLO_REHBER_RESIM = "resim";
    private static final String TABLO_REHBER_WEBSITE = "webSite";
    private static final String TABLO_REHBER_NOTICERIGI = "notIcerigi";


    public DatabaseHelper(Context context) {
        super(context, VERITABANI_ADI, null, VERITABANI_SURUMU);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {
        /*
        onCreate metodu, Veritabanının üretilmesi zamanını temsil eder.
        Bu metot içerisinde, veritabanı oluşturulma zamanında çalıştırılması gereken sorgular
        buraya eklenir.

        Tablo üretme sorguları (create) ve varsayılan tablo insert sorguları buraya eklenir.
         */

        StringBuilder sb = new StringBuilder();
        sb.append("CREATE TABLE IF NOT EXISTS " + DB_TABLO_REHBER + " (");
        sb.append(TABLO_REHBERID + " INTEGER PRIMARY KEY AUTOINCREMENT,");
        sb.append(TABLO_REHBER_AD + " VARCHAR (75),");
        sb.append(TABLO_REHBER_SOYAD + " VARCHAR (75),");
        sb.append(TABLO_REHBER_TELEFONNO + " VARCHAR (25),");
        sb.append(TABLO_REHBER_MAILADRESI + "	VARCHAR (75),");
        sb.append(TABLO_REHBER_TELEFONTURU + " VARCHAR (75),");
        sb.append(TABLO_REHBER_RESIM + " VARCHAR,");
        sb.append(TABLO_REHBER_WEBSITE + " VARCHAR,");
        sb.append(TABLO_REHBER_NOTICERIGI + " TEXT");
        sb.append(")");

        db.execSQL(sb.toString());

    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        /*
        Veritabanı güncellenmesi amacıyla kullanılır.

        Yeni eklenen tablolar, kolonlar gibi değişiklikleri güncel yazılıma adapte etmek için
        eski veritabanı sürümü, yeni bie aürüm ile değişirse bu metot çalışabilir.
         */


        // Eğer varsa tabloları sil
        db.execSQL("DROP TABLE IF EXISTS " + DB_TABLO_REHBER);

        // Veritabanını tekrar üret
        onCreate(db);
    }


    public void rehbereKisiEkle(Rehber kisi) {
        SQLiteDatabase db = this.getWritableDatabase();

        /*
        getWritableDatabase() metodu veritabanına yazmak amaçlı bağlantı açar.
         */
        ContentValues veri = new ContentValues();
        veri.put(TABLO_REHBER_AD, kisi.getAd());
        veri.put(TABLO_REHBER_MAILADRESI, kisi.getMailAdresi());
        veri.put(TABLO_REHBER_RESIM, kisi.getResim());
        veri.put(TABLO_REHBER_NOTICERIGI, kisi.getNot());
        veri.put(TABLO_REHBER_SOYAD, kisi.getSoyad());
        veri.put(TABLO_REHBER_TELEFONNO, kisi.getTelefonNo());
        veri.put(TABLO_REHBER_TELEFONTURU, kisi.getTelefonTuru());
        veri.put(TABLO_REHBER_WEBSITE, kisi.getWebSite());
        db.insert(DB_TABLO_REHBER, null, veri);

        /*
    Key ve value formatında ContentValues sınıfı sayesinde veritabanında ilgili
    tabloya veri ekleme işlemi yaptık.
    Eklenecek verileri Metot argümanı olan Rehber sınıfından çektik.
     */

        db.close();
    }


    public Rehber getRehberKisi(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("select * from " + DB_TABLO_REHBER + " where " + TABLO_REHBERID + "=" + id, null);

        if (cursor != null)
            cursor.moveToFirst();

        Rehber rehber = new Rehber();

        return rehber;

        /*
        id'sini bildiğimiz bir satır verisini,bize Rehber mdoelinde geri döndürsün.
         */
    }

    public List<Rehber> getTumKisiler() {
        List<Rehber> rehberList = new ArrayList<Rehber>();
        // Select All Query
        String selectQuery = "SELECT  * FROM " + DB_TABLO_REHBER;

        SQLiteDatabase db = this.getWritableDatabase();
        Cursor c = db.rawQuery(selectQuery, null);

        // looping through all rows and adding to list
        if (c.moveToFirst()) {
            do {
                Rehber rehber = new Rehber();
                rehber.setAd(c.getString(c.getColumnIndex(TABLO_REHBER_AD)));
                rehber.setId(c.getInt(c.getColumnIndex(TABLO_REHBERID)));
                rehber.setMailAdresi(c.getString(c.getColumnIndex(TABLO_REHBER_MAILADRESI)));
                rehber.setNot(c.getString(c.getColumnIndex(TABLO_REHBER_NOTICERIGI)));
                rehber.setResim(c.getString(c.getColumnIndex(TABLO_REHBER_RESIM)));
                rehber.setTelefonNo(c.getString(c.getColumnIndex(TABLO_REHBER_TELEFONNO)));
                rehber.setTelefonTuru(c.getString(c.getColumnIndex(TABLO_REHBER_TELEFONTURU)));
                rehber.setWebSite(c.getString(c.getColumnIndex(TABLO_REHBER_WEBSITE)));
                rehberList.add(rehber);

            } while (c.moveToNext());
        }
        /*
        Cursor sınfı, veritabanına gönderilen select sorgusundan dönen tüm sonuçların
        listelenmesş ve kolon değerlerinin listelenmesi amaçlı kullanılır.
         */

        /*
        c.getInt() --> int olan bir kolonun değerini yazdırır.
        c.getString() --> String olan bir kolonun değerini yazdırır.
        c.getColumnIndex --> String olarak kolon adını bilidğimiz değerin, indisini verir.
         */


        // return contact list
        return rehberList;
    }

    public int kisiGuncelle(Rehber kisi) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues veri = new ContentValues();
        veri.put(TABLO_REHBER_AD, kisi.getAd());
        veri.put(TABLO_REHBER_MAILADRESI, kisi.getMailAdresi());
        veri.put(TABLO_REHBER_RESIM, kisi.getResim());
        veri.put(TABLO_REHBER_NOTICERIGI, kisi.getNot());
        veri.put(TABLO_REHBER_SOYAD, kisi.getSoyad());
        veri.put(TABLO_REHBER_TELEFONNO, kisi.getTelefonNo());
        veri.put(TABLO_REHBER_TELEFONTURU, kisi.getTelefonTuru());
        veri.put(TABLO_REHBER_WEBSITE, kisi.getWebSite());

        // ID değerini bildiğimiz bir satırın değerlerini güncelledik.
        return db.update(DB_TABLO_REHBER, veri, TABLO_REHBERID + " = ?",
                new String[]{String.valueOf(kisi.getId())});
    }

    public int getRehberKisiSayisi() {
        String countQuery = "SELECT  * FROM " + DB_TABLO_REHBER;
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(countQuery, null);
        cursor.close();

        return cursor.getCount();

        /*
        Select sorgusundan dönen tüm satır sayısını döndüren metottur.
         */
    }


    public void kisiSil(Rehber kisi) {
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(DB_TABLO_REHBER, TABLO_REHBERID + " = ?",
                new String[]{String.valueOf(kisi.getId())});
        db.close();
        /*
        Veritabanından kişi silmek için, id değerini bildiğimiz bir satırı silebiliriz.
        Argümandan rehber tipinde veri alarak kisi nesnesinin getId() metodundan kişinin
        id'sini yakalayabiliriz.
         */
    }

}

