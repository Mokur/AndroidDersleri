package com.example.lab08.sql.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.example.lab08.sql.Model.Rehber;
import com.example.lab08.sql.R;


import java.util.ArrayList;

public class AdapterRehber extends BaseAdapter {
     private Context context;
     private LayoutInflater layoutInflater;
     private ArrayList<Rehber>rehberler;

    public AdapterRehber() {
    }

    public AdapterRehber(Context context,ArrayList<Rehber> rehberler) {
        this.context = context;
        this.layoutInflater =(LayoutInflater)context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        this.rehberler = rehberler;
    }

    @Override
    public int getCount() {
        return rehberler.size();
    }

    @Override
    public Object getItem(int position) {
        return rehberler.get(position);
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = layoutInflater.inflate(R.layout.kisisatirgoruntusu,null);

        TextView tvAd,tvSoyad,tvTelefon,tvTelefonTur;
        ImageView ivResim;

        tvAd = v.findViewById(R.id.tvAd);
        tvSoyad = v.findViewById(R.id.tvSoyad);
        tvTelefon = v.findViewById(R.id.tvTelefon);
        tvTelefonTur = v.findViewById(R.id.tvTelefonTur);
        ivResim = v.findViewById(R.id.ivResim);

        tvAd.setText(rehberler.get(position).getAd());
        tvSoyad.setText(rehberler.get(position).getSoyad());
        tvTelefon.setText(rehberler.get(position).getTelefonNo());
        tvTelefonTur.setText(rehberler.get(position).getTelefonTuru());

        Glide.with(context).load(rehberler.get(position).getResim()).into(ivResim);













        return v;
    }
}
