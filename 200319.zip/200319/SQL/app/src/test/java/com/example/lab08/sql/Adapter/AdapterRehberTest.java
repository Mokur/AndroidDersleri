package com.example.lab08.sql.Adapter;

import static org.junit.Assert.*;

public class AdapterRehberTest {

}