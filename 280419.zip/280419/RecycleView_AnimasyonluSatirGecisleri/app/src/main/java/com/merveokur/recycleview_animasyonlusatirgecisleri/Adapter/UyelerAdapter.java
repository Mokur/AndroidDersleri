package com.merveokur.recycleview_animasyonlusatirgecisleri.Adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;

import com.bumptech.glide.Glide;
import com.merveokur.recycleview_animasyonlusatirgecisleri.Holder.UyelerHolder;
import com.merveokur.recycleview_animasyonlusatirgecisleri.Model.Uyeler;
import com.merveokur.recycleview_animasyonlusatirgecisleri.R;

import java.util.ArrayList;

public class UyelerAdapter extends RecyclerView.Adapter<UyelerHolder> {

    private Context context;
    private ArrayList<Uyeler> uyeler = new ArrayList<>();

    public UyelerAdapter() {
    }

    public UyelerAdapter(Context context, ArrayList<Uyeler> uyeler) {
        this.context = context;
        this.uyeler = uyeler;
    }

    @NonNull
    @Override
    public UyelerHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {

        View v = LayoutInflater.from(context).inflate(R.layout.item_layout,viewGroup,false);

        return new UyelerHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull UyelerHolder uyelerHolder, int i) {


        Animation animation = AnimationUtils.loadAnimation(uyelerHolder.itemView.getContext(),R.anim.item_animation_fall_down);
        uyelerHolder.itemView.startAnimation(animation);


        uyelerHolder.txtEmail.setText(uyeler.get(i).getEmail());
        uyelerHolder.txtAd.setText(uyeler.get(i).getAd());

        Glide
                .with(context)
                .load(uyeler.get(i).getProfilResim())
                .into(uyelerHolder.profilResim);



    }

    @Override
    public int getItemCount() {
        return uyeler.size();
    }
}
