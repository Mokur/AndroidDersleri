package com.merveokur.recycleview_animasyonlusatirgecisleri.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;

import com.merveokur.recycleview_animasyonlusatirgecisleri.Adapter.UyelerAdapter;
import com.merveokur.recycleview_animasyonlusatirgecisleri.Model.Uyeler;
import com.merveokur.recycleview_animasyonlusatirgecisleri.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    UyelerAdapter adapterUyeler;
    RecyclerView recyclerView;
    ArrayList<Uyeler> uyeler;

    public void doldur(int sayi){
        for (int i = 0; i <sayi; i++) {
            uyeler.add(
                    new Uyeler(
                            "Ad Soyad"+i,
                            "Email"+i,
                            "http://https://www.rd.com/wp-content/uploads/2017/09/01-shutterstock_476340928-Irina-Bg-1024x683.jpg"
                    )
            );

        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);

        adapterUyeler = new UyelerAdapter(getApplicationContext(),uyeler);


        int resId = R.anim.layout_animation_fall_down;
        LayoutAnimationController animation = AnimationUtils.loadLayoutAnimation(getApplicationContext(),resId);
        //recyclerView.setItemAnimator(animation);


        LinearLayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapterUyeler);
    }
}
