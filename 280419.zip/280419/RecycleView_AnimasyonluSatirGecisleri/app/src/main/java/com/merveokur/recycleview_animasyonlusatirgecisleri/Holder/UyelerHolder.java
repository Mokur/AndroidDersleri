package com.merveokur.recycleview_animasyonlusatirgecisleri.Holder;

import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.merveokur.recycleview_animasyonlusatirgecisleri.R;

public class UyelerHolder extends RecyclerView.ViewHolder {

    public TextView txtAd, txtEmail;
    public ImageView profilResim;

    public UyelerHolder(@NonNull View itemView) {
        super(itemView);
         txtAd = itemView.findViewById(R.id.txtAd);
         txtEmail = itemView.findViewById(R.id.txtEmail);
         profilResim = itemView.findViewById(R.id.profilResim);
    }

}
