package com.serifgungor.sqliteveritabankullanm.Activity;

import android.app.Dialog;
import android.content.DialogInterface;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import com.serifgungor.sqliteveritabankullanm.Adapter.AdapterRehber;
import com.serifgungor.sqliteveritabankullanm.Model.Rehber;
import com.serifgungor.sqliteveritabankullanm.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    EditText etArama;
    Button btnKisiEkle;
    ListView listViewKisiler;

    AdapterRehber adapterRehber;
    ArrayList<Rehber> rehberKisiler = new ArrayList<>();


    private void kisiGuncelleDialog(
            int id,
            String ad,
            String soyad,
            String email,
            String not,
            String telefon,
            String telefonTur,
            String webSite
    ){
        Dialog dialog = new Dialog(MainActivity.this);
        dialog.setContentView(R.layout.rehber_kisiguncelle);

        EditText etAd,etSoyad,etMail,etNot,etTelefon,etTelefonTur,etWeb;
        Button btnIslem;

        etAd = dialog.findViewById(R.id.etRehberAd);
        etSoyad = dialog.findViewById(R.id.etRehberSoyad);
        etMail = dialog.findViewById(R.id.etRehberMailAdresi);
        etNot = dialog.findViewById(R.id.etRehberNot);
        etTelefon = dialog.findViewById(R.id.etRehberTelefon);
        etTelefonTur = dialog.findViewById(R.id.etRehberTelefonTur);
        etWeb = dialog.findViewById(R.id.etRehberWebSite);
        btnIslem = dialog.findViewById(R.id.btnRehberIslem);

        etAd.setText(ad);
        etSoyad.setText(soyad);
        etMail.setText(email);
        etNot.setText(not);
        etTelefon.setText(""+telefon);
        etTelefonTur.setText(telefonTur);
        etWeb.setText(webSite);

        btnIslem.setText("Güncelle");
        btnIslem.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

            }
        });

        dialog.show();

    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etArama = findViewById(R.id.etArama);
        btnKisiEkle = findViewById(R.id.btnKisiEkle);
        listViewKisiler = findViewById(R.id.listViewKisiler);

        /*
        int id, String ad, String soyad, String telefonNo, String mailAdresi, String telefonTuru, String resim, String webSite, String not
         */
        rehberKisiler.add(new
                Rehber(
                        1,
                        "ŞERİF",
                        "GÜNGÖR",
                        "05369997788",
                        "contact@serifgungor.com",
                        "Cep",
                        "https://serifgungor.com/images/my-photo.jpg",
                        "https://serifgungor.com",
                        "not"
                )
        );
        rehberKisiler.add(new
                        Rehber(
                        1,
                        "ŞERİF",
                        "GÜNGÖR",
                        "05369997788",
                        "contact@serifgungor.com",
                        "Cep",
                        "https://serifgungor.com/images/my-photo.jpg",
                        "https://serifgungor.com",
                        "not"
                )
        );

        adapterRehber = new AdapterRehber(getApplicationContext(), rehberKisiler);
        listViewKisiler.setAdapter(adapterRehber);

        listViewKisiler.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {


                AlertDialog.Builder adb = new AlertDialog.Builder(MainActivity.this);
                adb.setTitle("İşlem seçiniz");
                adb.setMessage("Silmek yada Güncellemek üzere bir butona tıklayınız.");

                adb.setPositiveButton("Güncelle", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        /*
                        int id,
            String ad,
            String soyad,
            String email,
            String not,
            String telefon,
            String telefonTur,
            String webSite
                         */
                        kisiGuncelleDialog(
                                rehberKisiler.get(position).getId(),
                                rehberKisiler.get(position).getAd(),
                                rehberKisiler.get(position).getSoyad(),
                                rehberKisiler.get(position).getMailAdresi(),
                                rehberKisiler.get(position).getNot(),
                                rehberKisiler.get(position).getTelefonNo(),
                                rehberKisiler.get(position).getTelefonTuru(),
                                rehberKisiler.get(position).getWebSite()
                        );

                    }
                });

                adb.setNegativeButton("Sil", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                adb.setNeutralButton("Vazgeç",null);
                adb.create();
                adb.show();





                return false;
            }
        });

    }
}
